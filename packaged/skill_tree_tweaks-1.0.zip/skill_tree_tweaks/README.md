# Credits

1. -Ry for the python code
2. sleepmaster for their custom ui

# Features

1. Showing skills effected by class mod
2. Custom Cyan UI outline for augmented skills (both Active and Inactive variants)
3. Custom descriptions
4. Reduced font size
5. Text Colour Coding
    - Green/Lime is Current Value
    - Cyan/Blue is Next Value
    - Red indicates augmented skill currently has no effect
    - Gold/Yellow is for Maxed out skills

# Installation

1. Extract and replace the contents of WillowGame with `custom_ui_full.zip` (or use a mod manager)
