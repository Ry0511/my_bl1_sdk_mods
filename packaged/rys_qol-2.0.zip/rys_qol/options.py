from mods_base import BoolOption

_should_sort_fast_travels = BoolOption("Sort Fast Travel Stations", True)
_fix_auto_mission_select = BoolOption("Sort Fix Auto-Mission Select", True)
