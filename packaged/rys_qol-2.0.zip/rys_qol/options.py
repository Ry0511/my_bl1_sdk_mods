from mods_base import BoolOption

_should_sort_fast_travels = BoolOption("Sort Fast Travel Stations", True)
