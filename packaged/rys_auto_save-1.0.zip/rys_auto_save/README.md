# Ry's Autosave

Simple mod that will auto-save the active save file at a configurable rate.

# Features

- Configurable Frequency
  - default is every 60 seconds
- Can be disabled via an option
- Configurable Save Destination
  - default is to save to `Autosave-Filename.sav`
  - Can also save to current/active save